import React, { useContext } from 'react';
import list from '../data';
import { CartContext } from '../context/CartContext';
import './Subscriptions.css';

const Subscriptions = () => {
  const { addItem } = useContext(CartContext);

  return (
    <div className="grid">
      {list.map(item => (
        <div key={item.id} className="card">
          <img src={item.img} alt={item.service} className="thumb"/>
          <h3>{item.service}</h3>
          <p className="info">{item.serviceInfo}</p>
          <p className="price">${item.price.toFixed(2)}</p>
          <button className="btn" onClick={() => addItem(item)}>Add to Cart</button>
        </div>
      ))}
    </div>
  );
};

export default Subscriptions;
