import React, { useState, useEffect } from 'react';
import EventItem from './EventItem';
import './StreamList.css';

function StreamList() {
  // Pull any saved events out of localStorage when the component first mounts
  const [events, setEvents] = useState(() => {
    const saved = localStorage.getItem('streamlist-events');
    return saved ? JSON.parse(saved) : [];
  });

  const [input, setInput] = useState('');

  // Anytime the events array changes, write it back to localStorage
  useEffect(() => {
    localStorage.setItem('streamlist-events', JSON.stringify(events));
  }, [events]);

  // Add a new event
  const handleSubmit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;

    const newEvent = {
      id: Date.now(),
      text: input.trim(),
      completed: false,
    };

    setEvents([newEvent, ...events]);
    setInput('');
  };

  // Delete an event
  const handleDelete = (id) => {
    setEvents(events.filter(event => event.id !== id));
  };

  // Toggle an event's completed state
  const handleToggleComplete = (id) => {
    setEvents(events.map(event =>
      event.id === id ? { ...event, completed: !event.completed } : event
    ));
  };

  // Edit an existing event's text
  const handleEdit = (id, newText) => {
    setEvents(events.map(event =>
      event.id === id ? { ...event, text: newText } : event
    ));
  };

  return (
    <div className="stream-container">
      <h2 className="stream-heading">My Stream List</h2>

      <form onSubmit={handleSubmit} className="stream-form">
        <input
          type="text"
          placeholder="Enter title..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          className="stream-input"
        />
        <button type="submit" className="stream-submit">Add</button>
      </form>

      <ul className="event-list">
        {events.length === 0 && <li>No items yet – add one above!</li>}
        {events.map(event => (
          <EventItem
            key={event.id}
            event={event}
            onDelete={handleDelete}
            onToggleComplete={handleToggleComplete}
            onEdit={handleEdit}
          />
        ))}
      </ul>
    </div>
  );
}

export default StreamList;