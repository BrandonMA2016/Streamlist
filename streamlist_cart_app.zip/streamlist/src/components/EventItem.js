
import React, { useState } from 'react';
import { FaCheckCircle, FaRegCircle, FaEdit, FaTrash, FaSave } from 'react-icons/fa';

function EventItem({ event, onDelete, onToggleComplete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(event.text);

  const handleSave = () => {
    onEdit(event.id, editValue);
    setIsEditing(false);
  };

  return (
    <li className={`event-item ${event.completed ? 'completed' : ''}`}>
      {isEditing ? (
        <>
          <input
            type="text"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value)}
            className="edit-input"
          />
          <button onClick={handleSave} title="Save">
            <FaSave />
          </button>
        </>
      ) : (
        <>
          <span onClick={() => onToggleComplete(event.id)} className="event-text">
            {event.completed ? <FaCheckCircle /> : <FaRegCircle />} {event.text}
          </span>
          <div className="actions">
            <button onClick={() => setIsEditing(true)} title="Edit">
              <FaEdit />
            </button>
            <button onClick={() => onDelete(event.id)} title="Delete">
              <FaTrash />
            </button>
          </div>
        </>
      )}
    </li>
  );
}

export default EventItem;
