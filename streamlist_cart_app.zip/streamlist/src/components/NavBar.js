import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import { CartContext } from '../context/CartContext';
import './NavBar.css';

const NavBar = () => {
  const { cart } = useContext(CartContext);
  const count = cart.reduce((sum, item) => sum + item.qty, 0);

  return (
    <nav className="nav">
      <Link to="/" className="logo">StreamList</Link>
      <div className="links">
        <Link to="/">Subscriptions</Link>
        <Link to="/cart">Cart ({count})</Link>
      </div>
    </nav>
  );
};

export default NavBar;
