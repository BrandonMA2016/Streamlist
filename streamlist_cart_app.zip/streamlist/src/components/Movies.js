import React, { useState } from 'react';
import './StreamList.css'; // reuse basic styles

const TMDB_IMAGE_ROOT = 'https://image.tmdb.org/t/p/w200';

function Movies() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [error, setError] = useState('');

  const searchMovies = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    const apiKey = process.env.REACT_APP_TMDB_KEY || 'YOUR_TMDB_API_KEY';
    if (apiKey === 'YOUR_TMDB_API_KEY') {
      setError('⚠️ Please add your TMDB API key to a .env file before searching.');
      return;
    }

    try {
      setError('');
      const url = `https://api.themoviedb.org/3/search/movie?api_key=${apiKey}&query=${encodeURIComponent(query)}`;
      const res = await fetch(url);
      const data = await res.json();

      if (data && data.results) {
        setResults(data.results);
      } else {
        setResults([]);
        setError('No results found.');
      }
    } catch (err) {
      setError('Something went wrong while fetching data.');
      console.error(err);
    }
  };

  return (
    <div className="stream-container">
      <h2 className="stream-heading">Search Movies (TMDB)</h2>

      <form onSubmit={searchMovies} className="stream-form">
        <input
          type="text"
          placeholder="Search by title..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="stream-input"
        />
        <button type="submit" className="stream-submit">Search</button>
      </form>

      {error && <p style={{ color: 'red' }}>{error}</p>}

      <div className="movies-grid">
        {results.map(movie => (
          <div key={movie.id} className="movie-card">
            {movie.poster_path ? (
              <img
                src={TMDB_IMAGE_ROOT + movie.poster_path}
                alt={movie.title}
                className="movie-poster"
              />
            ) : (
              <div className="movie-placeholder">No Image</div>
            )}
            <h3 className="movie-title">{movie.title}</h3>
            <p className="movie-overview">{movie.overview?.slice(0, 120) || 'No description.'}…</p>
            <p className="movie-meta">
              ⭐ {movie.vote_average}&nbsp; | &nbsp;📅 {movie.release_date || 'N/A'}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Movies;