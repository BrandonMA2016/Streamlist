import React, { createContext, useState, useEffect } from 'react';

export const CartContext = createContext();

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState(() => {
    const stored = localStorage.getItem('cart');
    return stored ? JSON.parse(stored) : [];
  });

  useEffect(() => {
    localStorage.setItem('cart', JSON.stringify(cart));
  }, [cart]);

  const addItem = (item) => {
    // Prevent multiple subscription items
    if (item.isSubscription) {
      const existingSub = cart.find(i => i.isSubscription);
      if (existingSub) {
        alert('You can only add one subscription at a time.');
        return;
      }
    }

    const existing = cart.find(i => i.id === item.id);
    if (existing && !item.isSubscription) {
      // Increase quantity for accessories
      setCart(cart.map(i => i.id === item.id ? { ...i, qty: i.qty + 1 } : i));
    } else if (!existing) {
      setCart([...cart, { ...item, qty: 1 }]);
    } else {
      alert('Subscription already in cart.');
    }
  };

  const removeItem = (id) => {
    setCart(cart.filter(i => i.id !== id));
  };

  const changeQty = (id, qty) => {
    if (qty <= 0) {
      removeItem(id);
    } else {
      setCart(cart.map(i => i.id === id ? { ...i, qty } : i));
    }
  };

  const total = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  return (
    <CartContext.Provider value={{ cart, addItem, removeItem, changeQty, total }}>
      {children}
    </CartContext.Provider>
  );
};
