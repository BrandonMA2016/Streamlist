const bcrypt = require('bcrypt');

// Sample password input from user
const password = 'StreamListSecurePass123';

// Hashing the password with salt
bcrypt.genSalt(10, (err, salt) => {
  if (err) throw err;

  bcrypt.hash(password, salt, (err, hash) => {
    if (err) throw err;
    console.log('Hashed Password:', hash);

    // Simulate password check
    bcrypt.compare(password, hash, (err, result) => {
      if (err) throw err;
      console.log('Password Match:', result); // Should print true
    });
  });
});
