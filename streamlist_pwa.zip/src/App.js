
import React, { useState, useEffect } from 'react';
import './App.css';

const API_KEY = 'YOUR_TMDB_API_KEY';

function App() {
  const [search, setSearch] = useState('');
  const [results, setResults] = useState([]);
  const [myList, setMyList] = useState(() => {
    const saved = localStorage.getItem('streamlist');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('streamlist', JSON.stringify(myList));
  }, [myList]);

  const handleSearch = async () => {
    const res = await fetch(
      `https://api.themoviedb.org/3/search/movie?api_key=${API_KEY}&query=${search}`
    );
    const data = await res.json();
    setResults(data.results || []);
  };

  const addToList = (movie) => {
    if (!myList.find((m) => m.id === movie.id)) {
      setMyList([...myList, movie]);
    }
  };

  const removeFromList = (id) => {
    setMyList(myList.filter((movie) => movie.id !== id));
  };

  return (
    <div className="App">
      <h1>StreamList</h1>
      <input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search for a movie..."
      />
      <button onClick={handleSearch}>Search</button>

      <h2>Search Results</h2>
      <ul>
        {results.map((movie) => (
          <li key={movie.id}>
            {movie.title}
            <button onClick={() => addToList(movie)}>Add</button>
          </li>
        ))}
      </ul>

      <h2>My Movie List</h2>
      <ul>
        {myList.map((movie) => (
          <li key={movie.id}>
            {movie.title}
            <button onClick={() => removeFromList(movie.id)}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
