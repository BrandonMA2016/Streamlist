import React from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const navigate = useNavigate();

  const handleLogin = () => {
    localStorage.setItem("auth", "true");
    navigate("/");
  };

  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h2>Login to EZTechMovie</h2>
      <button onClick={handleLogin}>Login with Google (Mock)</button>
    </div>
  );
}

export default Login;