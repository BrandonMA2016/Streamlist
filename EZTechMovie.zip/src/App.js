import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import Login from "./Login";
import Dashboard from "./Dashboard";
import CreditCardForm from "./CreditCardForm";

const isAuthenticated = () => {
  return localStorage.getItem("auth") === "true";
};

function App() {
  return (
    <Routes>
      <Route path="/" element={isAuthenticated() ? <Dashboard /> : <Navigate to="/login" />} />
      <Route path="/login" element={<Login />} />
      <Route path="/credit-card" element={isAuthenticated() ? <CreditCardForm /> : <Navigate to="/login" />} />
    </Routes>
  );
}

export default App;