import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function CreditCardForm() {
  const navigate = useNavigate();
  const [cardNumber, setCardNumber] = useState("");
  const [name, setName] = useState("");
  const [expiry, setExpiry] = useState("");
  const [cvv, setCvv] = useState("");

  const formatCardNumber = (value) => {
    return value.replace(/[^0-9]/g, "").replace(/(.{4})/g, "$1 ").trim();
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    localStorage.setItem("creditCard", JSON.stringify({ name, cardNumber, expiry, cvv }));
    alert("Credit card saved!");
    navigate("/");
  };

  return (
    <form onSubmit={handleSubmit} style={{ maxWidth: "400px", margin: "50px auto", display: "flex", flexDirection: "column", gap: "10px" }}>
      <h3>Enter Credit Card Info</h3>
      <input type="text" placeholder="Name on Card" value={name} onChange={(e) => setName(e.target.value)} required />
      <input type="text" placeholder="1234 5678 9012 3456" maxLength="19" value={cardNumber} onChange={(e) => setCardNumber(formatCardNumber(e.target.value))} required />
      <input type="text" placeholder="MM/YY" value={expiry} onChange={(e) => setExpiry(e.target.value)} required />
      <input type="text" placeholder="CVV" maxLength="4" value={cvv} onChange={(e) => setCvv(e.target.value)} required />
      <button type="submit">Save Card</button>
    </form>
  );
}

export default CreditCardForm;